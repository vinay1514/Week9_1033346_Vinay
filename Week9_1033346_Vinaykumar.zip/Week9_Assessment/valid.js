function validateForm() {
    const name = document.getElementById("name");
    const email = document.getElementById("email");
    const rate = document.getElementById("rate");
    const where = document.getElementById("where");
    const emotions = document.querySelectorAll('input[name="emotion"]');
//checking for each element validations
    if (name.value === "") {
        alert("Name cannot be empty");
        name.focus();
        return false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (email.value === "" || !emailRegex.test(email.value)) {
        alert("Please enter a valid email address");
        email.focus();
        return false;
    }

    const rateValue = parseFloat(rate.value);
    if (rate.value === "" || rateValue < 1 || rateValue > 5) {
        alert("Please enter a valid rating between 1 and 5");
        rate.focus();
        return false;
    }

    if (where.value === "") {
        alert("Please specify where you heard about us");
        where.focus();
        return false;
    }

    let isChecked = false;
    emotions.forEach((emotion) => {
        if (emotion.checked) {
            isChecked = true;
        }
    });

    if (isChecked) {
        alert("Please select at least one emotion");
        return true;
    }

    alert("Form submitted successfully");
    return true;
}