function Form() {
  var name = document.getElementById[" signup-form"]["name"].value;
  var email = document.getElementById[" signup-form"]["email"].value;
  var password = document.getElementById[" signup-form"]["password"].value;
  var confirmPassword = document.getElementById[" signup-form"]["confirm-password"].value;
  var hobbies = document.getElementById[" signup-form"]["hobbies"].checked;
  if (name == "" || email == "" || password == "" || confirmPassword == "" || !hobbies) {
    alert("Please fill in all the required fields.");
    return false;
  }
  if (password != confirmPassword) {
    alert("Passwords do not match.");
    return false;
  }
  if (!email.includes('@')) {
    alert("Please enter a valid email address.");
    return false;
  }
  return true;
}
function verifyPassword() {  
  var pw = document.getElementById("password").value;  
  //check empty password field  
  if(pw == "") {  
     document.getElementById("message").innerHTML = "**Fill the password please!";  
     return false;  
  }  
   
 //minimum password length validation  
  if(pw.length < 8) {  
     document.getElementById("message").innerHTML = "**Password length must be atleast 8 characters";  
     return false;  
  }
}